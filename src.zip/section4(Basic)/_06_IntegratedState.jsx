import {useState} from 'react';

export default function _4_IntegratedState() {
    const [state, setState] = useState({
        name : "",
        gender : "",
        bio : ""
    })

    const onChange = (e) => {
        console.log(e.target.name + " : " + e.target.value)
        setState({
            ...state, // ...state는 전개연산자로, 업데이트 되기전의 state값을 넣어준다 (기존의 다른 값들은 유지시키기 위해)
            [e.target.name] : e.target.value, // 계산된 프로퍼티 (대괄호는 안에 있는 것을 표현식으로 평가되며, 그 결과는 객체의 새로운 속성 이름으로 사용)
            // 참고: ...state에 이미 존재하는 속성이 있다면 e.target.value으로 덮어씌운다
        })
    }

    return ( 
        <div>
            <div>
                <input name={"name"} value={state.name} onChange={onChange}/>
            </div>
            <div>
                <select name={"gender"} value={state.gender} onChange={onChange}>
                    <option>밝히지 않음</option>
                    <option value="male">남성</option>
                    <option value="female">여성</option>
                </select>
            </div>  
            <div>
                <textarea name={"bio"} value={state.bio} onChange={onChange}/>
            </div>
        </div>
    )
}