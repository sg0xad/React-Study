import { useState } from 'react';

function Lightbulb({light}) {
    return (
    <>
        {light === 'ON' ? (
        <div style={{backgroundColor:"orange"}}>ON</div>
        ) : (
        <div style={{backgroundColor:"gray"}}>OFF</div>
        )}
    </>
    )
}

function StaticLightbulb() {
    console.log('StaticLightbulb 컴포넌트가 렌더링 되었습니다.')
    return (
        <div style={{backgroundColor:"gray"}}>OFF</div>
    )
}

export default function _2_State() {
    const [light, setLight] = useState("OFF") // 배열의 구조분해할당 (첫번째: state값, 두번째: 상태변화함수 / useState(초기값))
    // state가 바뀌면 _2_State 컴포넌트 리렌더링
    return (
    <div>
        <Lightbulb light={light}/>{/* props가 바뀌면 Lightbulb 컴포넌트 리렌더링 */}
        <StaticLightbulb/> {/* 부모 컴포넌트인 _2_Body 컴포넌트가 리렌더링 되면 StaticLightbulb 컴포넌트도 리렌더링 */}
        <button onClick={()=>{setLight("ON")}}>켜기</button> {/* 이벤트 핸들링 */}
        <button onClick={()=>{setLight("OFF")}}>끄기</button>
    </div>
    )
 
}