import Button from './components/Button';
import SecondButton from './components/SecondButton';
export default function _03_Props() {
    const buttonProps = {
        text: "2번 버튼",
        color: "green",
    }
    return (
        <div>
            {/* Props 전달하기 첫번째 방법*/}
            {/* props을 전달하려면 반드시 부모 자식 관계여야 한다 */}
            <Button text={"1번 버튼"} color={"red"} />

            {/* Props 전달하기 두번째 방법 */}
            <Button {...buttonProps} />

            {/* html 태그나 컴포넌트 전달하기 */}
            <SecondButton >
                <div>버튼</div>
            </SecondButton>
            <hr/>
        </div>
    )
}