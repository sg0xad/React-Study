export default function SecondButton({children}) {
    return (
        <button>
            {children}
        </button>
    )
}