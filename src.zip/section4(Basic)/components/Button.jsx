
// export default function Button (props) {
//     console.log(props) // {color: "red", text: "2번 버튼"} 

//     /* <props 첫번째 사용 방법> */
//     // return <button 
//     //   style={{
//     //       backgroundColor: props.color,
//     //   }}>{props.text}</button>

//     /* <props 두번째 사용 방법> */
//     const {color, text} = props
//     return (
//         <button
//             style={{
//                 backgroundColor: color,
//             }}
//         >
//             {text}
//         </button>
//     )
// }

/* <props 세번째 사용 방법> */
export default function Button({color, text}) {
    const onClick = (e) => {
        alert("버튼을 클릭했습니다")
    }
     return (
        <button
        onClick={onClick}
            style={{
                backgroundColor: color,
            }}>
            {text}
        </button>
     )
}