import {useRef, useState} from 'react';

export default function _5_Ref() {
    const [name, setName] = useState("")

    const nameRef = useRef() // 레퍼런스 객체를 생성해서 반환 (레퍼런스 객체가 담고 있는 값은 컴포넌트가 리렌더링 되어도 유지)

    const onChange = (e) => {
       setName(e.target.value)
    }

    const onSubmit = () => {
        if(name === "") {
            nameRef.current.focus()
            return;
        }
        alert(`${name}님 회원가입을 축하합니다!`)
    }

    return ( 
        <div>
            <div>
                <label htmlFor="name">이름</label> {/* 자바스크립트에서 for는 예약어로 사용되므로, htmlFor */}
                <input
                id="name"
                ref={nameRef}
                value={name}
                onChange={onChange}></input>
            </div>
            <button onClick={onSubmit}>회원가입</button>
        </div>
    )
}