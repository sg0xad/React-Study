import { useState, useMemo } from 'react';

export default function _01_useMemo() {
  const [item, setItem] = useState(10);
  const [count, setCount] = useState(0);

  // const expensiveFunction = () => {
  //   console.log('재 연산을 진행합니다.')
  //   let i = 0
  //   while (i < 100000000) { 
  //       i++;
  //   }
  //   return i;
  // }

  // useMemo은 "메모이즈된" 즉, 기억된 결과값을 반환하므로 재 연산을 방지한다.
  const expensiveFunction = useMemo(() => {
    console.log('재 연산을 진행합니다.')
    let i = 0
    while (i < 100000000) { 
        i++;
    }
    return i;
  }, [count]) // 의존성 배열(count)가 바뀌었을 때만 콜백함수를 실행

  return (
    <div>
      <p>연산 결과: {expensiveFunction}</p> {/* expensiveFunction은 useMemo의 반환값이므로 함수가 아니므로 ()을 붙이지 않는다. (단, useMemo를 안쓰면 expensiveFunction()으로 해야함) */}
      <button onClick={() => setCount(count + 1)}>연산하기</button>
      <button onClick={() => setItem(item * 2)}>아이템 변경</button>
    </div>
  );
}

