import "./TodoItem.css";
import {memo} from 'react'

function TodoItem(
    {id, isDone, createdDate, content, onUpdate, onDelete}
) {

    const onChangeCheckbox = () => {
        onUpdate(id);
    }

    const onClickDeleteButton = () => {
        onDelete(id);
    };
    
    return <div className="TodoItem">
        <input onChange={onChangeCheckbox} type="checkbox" checked={isDone}/>
        <div className="content">{content}</div>
        <div className="date">{new Date(createdDate).toLocaleDateString()}</div>
        <button onClick={onClickDeleteButton}>삭제</button>
    </div>
}

// TodoItem은 memo를 적용해도 리렌더링 된다. 이유는 우선 props에는 함수가 있는 함수는 참조자료형이고, 참조자료형은 값이 아닌 주소를 참조한다.
// 그런데 부모의 부모 컴포넌트인 App 컴포넌트 안에 함수가 있고, 그 함수는 App 컴포넌트가 렌더링 될 때마다 생성되는데, 그때마다 생성된 새로운 주소값을 참조하기에
// props가 변경됐다고 판단되어 TodoItem에 memo를 적용해도 리렌더링이 발생하는 문제가 생긴다.
export default memo(TodoItem)
