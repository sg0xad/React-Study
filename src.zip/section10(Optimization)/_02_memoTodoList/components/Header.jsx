import "./Header.css"
import { memo } from 'react'

function Header() {
    return <div className="Header">
        <h1>
            {new Date().toDateString()}
        </h1>
    </div>
}

// props가 바뀌지 않는 이상 부모컴포넌트가 렌더링 돼도 리렌더링 x
const OptimizedHeaderComponent = memo(Header) // 인수로 컴포넌트를 받아서 최적화된 새로운 컴포넌트를 반환 

export default OptimizedHeaderComponent // 최적화된 컴포넌트를 export

// export default memo(Header) // 이렇게도 가능