function add(a, b) {
    return a + b;
}

function sub(a, b) {
    return a - b;
}

// module 객체는 node.js가 제공하는 기본적인 내장 객체
module.exports = {
    add,
    sub,
}