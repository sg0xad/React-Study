// function add(a, b) {
//     return a + b;
// }

// function sub(a, b) {
//     return a - b;
// }

// export { add, sub };

// 이렇게도 가능 =============================
export function add(a, b) {
    return a + b;
}

export function sub(a, b) {
    return a - b;
}

// export default를 통해 math 모듈을 대표하는 함수를 export 할 수 있다. (하나의 모듈에서는 단 한번의 export default 문만 이용 가능)
export default function mutiply(a, b) {
    return a * b;
}