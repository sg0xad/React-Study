// npmjs 사이트란? node.js 라이브러리들을 확인할 수 있는 사이트 (https://www.npmjs.com/)
// 터미널에서 'npm i randomcolor' 이런식으로 라이브러리를 설치할 수 있다.
// 라이브러리를 설치하게 되면 package.json에 "dependencies" 항목이 추가되며 설치된 라이브러리를 확인 할 수 있다.
// "randomcolor": "^0.6.2" 여기서 ^의 의미는 대략적인 버전이라는 접두사이다. (자세한 버전을 확인하려면 package-lock.json 에서 확인)
// package-lock.json, node_modules 등이 사라져도 package.json에 있는 "dependencies" 항목이 있기 때문에 'npm install'으로 "dependencies" 항목에 있는 모든 라이브러리 설치 가능 
// 프로젝트(패키지)를 공유할 때 node_modules은 용량이 굉장히 크기 때문에 package.json만 있으면 'npm install' 명령어가 있어서 node_modules는 공유 필요 x

import randomColor from 'randomcolor'; // 경로가 아닌 라이브러리 이름을 쓰면 node_modules 폴더에서 찾겠다는 의미

const color = randomColor();
console.log(color)