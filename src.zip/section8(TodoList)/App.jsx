import './App.css'
import Header from './components/Header'
import TodoEditor from './components/TodoEditor'
import TodoList from './components/TodoList'
import {useState, useRef} from 'react'

const mockData = [
  {
    id : 0,
    isDone : true,
    content : "React 공부하기",
    createdDate : new Date().getTime(),
  },
  {
    id : 1,
    isDone : false,
    content : "빨래 널기",
    createdDate : new Date().getTime(),
  },
  {
    id : 2,
    isDone : true,
    content : "음악 연습하기",
    createdDate : new Date().getTime(),
  },
]

function App() {
  const [todos, setTodos] = useState(mockData);
  const idRef = useRef(3)

  const onCreate = (content) => {
      const newTodo = {
        id : idRef.current++,
        idDone : false,
        // content : content,
        content,  // 변수명만 간결하게 넣으면 이 변수의 이름으로 키를 설정하고 변수의 값으로 키의 값이 설정된다.
        createdDate : new Date().getTime()
      }

      // todos.push(newTodo) // 값을 넣을 때는 setState으로만 해야 한다.
      setTodos(
        [newTodo, ...todos] // ..todos는 기존의 todos 배열에 담겨있던 모든 요소들이 펼쳐지고, newTodo라는 새로운 요소를 넣고 배열로 묶어서 업데이트
      )
  }

  const onUpdate = (targetId) => {
    setTodos(
        todos.map((todo) => 
          todo.id === targetId
            ? { ...todo, isDone: !todo.isDone} // isDone의 값을 바꿈
            : todo // 그냥 원래 todo를 반환
            )
    )
  }

  const onDelete = (targetId) => {
    setTodos(todos.filter((todo) => todo.id !== targetId)) // todo.id가 targetId와 같이 않은 것들만 반환
  }

  return (
    <div className="App">
      <Header/>
      <TodoEditor onCreate={onCreate}/>
      <TodoList todos={todos} onUpdate={onUpdate} onDelete={onDelete}/>
    </div>
  )
}

export default App
