import {useState, useEffect} from 'react'

function App() {
  const [posts, setPosts] = useState([]);

  // < 첫번째 방법 >
  useEffect(() => {
    // API에서 데이터를 가져오는 GET 요청을 수행합니다.
    fetch('https://jsonplaceholder.typicode.com/photos')
      .then(response => {
        // 네트워크 응답이 성공적이지 않은 경우 에러를 throw합니다.
        if (!response.ok) {
          throw new Error('Network response was not ok');
        }
        // JSON 형태의 응답을 파싱하여 다음 then 블록으로 전달합니다.
        return response.json();
      })
      .then(data => {
        // 성공적으로 파싱된 데이터를 상태로 설정하여 컴포넌트에 반영합니다.
        setPosts(data);
      })
      .catch(error => {
        // 오류가 발생한 경우 에러 메시지를 출력합니다.
        console.error('Error fetching data:', error);
      });
  }, []);

  // < 두번째 방법 >
  // useEffect(() => {
  //   const fetchData = async () => {
  //     try {
  //       // API에서 데이터를 가져오는 GET 요청을 수행하고 응답을 기다립니다.
  //       const response = await fetch('https://jsonplaceholder.typicode.com/photos');
        
  //       // 응답을 JSON으로 파싱하고 데이터를 기다립니다.
  //       const data = await response.json();
        
  //       // 성공적으로 데이터를 가져왔을 경우, 상태를 업데이트하여 컴포넌트에 반영합니다.
  //       setPosts(data);
  //     } catch (error) {
  //       // 오류가 발생한 경우, 콘솔에 오류 메시지를 출력합니다.
  //       console.log(error);
  //     }
  //   };
  //   fetchData();
  // }, []);

  return (
    <ul>
      {posts.map(post => (
        <li key={post.id}>
          <div>
            {post.title}
          </div>
          <div>
            <img src={post.thumbnailUrl} />
          </div>
          </li>
      ))}
    </ul>
  )
}

export default App
