import {useState, useEffect} from 'react'
import axios from 'axios' // axios를 사용하려면 터미널에 npm i axios 입력
function App() {
  const [posts, setPosts] = useState([]);

  // < 첫번째 방법 >
  useEffect(() => {
    axios({
      method: 'GET',
      url: 'https://jsonplaceholder.typicode.com/photos'
    }).then(response => setPosts(response.data))
  }, [])

  // < 두번째 방법 >
  // useEffect(() => {
  //   axios.get('https://jsonplaceholder.typicode.com/photos')
  //         .then(response => setPosts(response.data))
  // }, [])

  // < 세번째 방법 >
  // useEffect(() => {
  //   async function fetchData() {
  //     try {
  //       const response = await axios.get('https://jsonplaceholder.typicode.com/photos');
  //       setPosts(response.data);
  //     } catch (error) {
  //       console.log(error);
  //     }
  //   }
  //   fetchData();
  // }, []);
 

  return (
    <ul>
      {posts.map(post => (
        <li key={post.id}>
          <div>
            {post.title}
          </div>
          <div>
            <img src={post.thumbnailUrl} />
          </div>
          </li>
      ))}
    </ul>
  )
}

export default App
