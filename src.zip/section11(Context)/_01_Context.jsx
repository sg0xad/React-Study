import { createContext, useContext, useState } from 'react';

const MyContext = createContext(); // context 생성 (createContext()의 인수로 다른 컴포넌트들에게 공급할 데이터의 초기값을 넣을 수 있다)

const ChildComponent = () => {
    const {value, setValue} = useContext(MyContext); // context 사용
    return (
        <>
            <div>{value}</div>
            <div><input type="text" value={value} onChange={(e)=>setValue(e.target.value)}/></div>
        </>
    );
};

const _01_Context = () => {
    const [value, setValue] = useState('Hello, Context'); // state 설정

    return (
        <MyContext.Provider value={{value, setValue}}> {/* TodoContext.Provider로 컴포넌트들을 감싸면 모든 자손 컴포넌트들이 데이터를 공급받을 수 있다. */}
            <ChildComponent />
        </MyContext.Provider>
    );
};

export default _01_Context;