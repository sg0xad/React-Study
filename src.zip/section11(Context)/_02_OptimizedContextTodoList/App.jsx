import './App.css'
import Header from './components/Header'
import TodoEditor from './components/TodoEditor'
import TodoList from './components/TodoList'
import { useRef, useReducer, useCallback, useMemo } from 'react'
import { TodoStateContext, TodoDispatchContext } from './TodoContext'

const mockData = [
  {
    id : 0,
    isDone : true,
    content : "React 공부하기",
    createdDate : new Date().getTime(),
  },
  {
    id : 1,
    isDone : false,
    content : "빨래 널기",
    createdDate : new Date().getTime(),
  },
  {
    id : 2,
    isDone : true,
    content : "음악 연습하기",
    createdDate : new Date().getTime(),
  },
]

function reducer(state, action) {
  switch(action.type) {
    case 'CREATE': {
      return [action.data, ...state]
    }
    case 'UPDATE': {
      return state.map((it)=>it.id === action.data? {...it, isDone : !it.isDone} : it)
    }
    case 'DELETE': {
      return state.filter((it) => it.id !== action.data)
    }
  }
}

function App() {
  const [todos, dispatch] = useReducer(reducer, mockData);
  const idRef = useRef(3)

  const onCreate = (content) => {
      dispatch({
        type : "CREATE",
        data : {
          id : idRef.current++,
          idDone : false,
          content, 
          createdDate : new Date().getTime()
        }
      })
  }

  const onUpdate = useCallback((targetId) => {
    dispatch({
      type: "UPDATE",
      data: targetId,
    })
  }, []) 

  const onDelete = useCallback((targetId) => {
    dispatch({
      type : "DELETE",
      data: targetId,
    })
  }, []); 

  // App 컴포넌트가 리렌더링 되면 ContextPrvider value의 객체도 재생성 되기 때문에 useMemo 이용
  const memoizedDispatches = useMemo(() => { 
    return {
      onCreate,
      onUpdate,
      onDelete
    }
  }, [])


  return (
    <div className="App"> 
      <Header/> 
      <TodoStateContext.Provider value={todos}> {/* value가 변경될 수 있는 값 */}
        <TodoDispatchContext.Provider value={memoizedDispatches}> {/* value가 변경될 수 없는 값 */}
          <TodoEditor/>
          <TodoList />
        </TodoDispatchContext.Provider>
      </TodoStateContext.Provider>
    </div>
  )
}

export default App
