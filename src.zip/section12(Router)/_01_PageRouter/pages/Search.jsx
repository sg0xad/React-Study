export default function Search() {
    return <div>Search</div>
}