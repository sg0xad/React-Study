export default function Country() {
    return <div>Country</div>
}