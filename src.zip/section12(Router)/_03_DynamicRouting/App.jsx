import {Routes, Route, Link, useNavigate} from 'react-router-dom'
import Home from './pages/Home'
import Search from './pages/Search'
import Country from './pages/Country'
import NotFound from './pages/NotFound'

function App() {
    // <Dynamic Routing>
    // Query String: URL뒤에 ?{이름}={값} 형태로 동적인 값을 전달함
    // URL Parameter: URL 뒤에 /{값} 형태로 동적인 데이터를 전달함
    
    const nav = useNavigate() // nav 변수에 useNavigate 훅이 반환하는 페이지를 이동시킬 수 있는 함수가 저장
    const onClick = () => {
        nav('/search')
    }
    
    return (
        <>
        <Routes>
            <Route path="/" element={<Home/>}/> 
            <Route path="/search" element={<Search/>}/> 
            <Route path="/country/:code" element={<Country/>}/> {/* URL Parameter를 설정 (주소창에 URL 변수 안쓰면 404 NotFound) */}
            <Route path="*" element={<NotFound/>}/>
        </Routes>
        <div>
            <Link to={'/'}>Home</Link>
            <Link to={'/search'}>Search</Link>
            <Link to={'/country'}>Country</Link>
            <button onClick={onClick}>서치 페이지로 이동</button>
        </div>
        </>
    )
}

export default App