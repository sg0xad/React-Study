import { fetchCountries } from '../api'
import {useState, useEffect} from 'react'
import CountryList from '../components/CountryList'
import Searchbar from '../components/Searchbar'
import style from './Home.module.css'

export default function Home() {
    const [countries, setCountries] = useState([])

    const setInitData = async() => {
        const data = await fetchCountries() // fetchCountries는 async 함수이기 때문에 불러올 때도 await으로 불러와야 한다.
        setCountries(data)
    }

    useEffect(() => {
        setInitData()
    }, [])

    return (
    <div className={style.container}>
        <Searchbar/>
        <CountryList countries={countries}/>
    </div>
    )
}