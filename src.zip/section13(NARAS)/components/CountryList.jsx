import CountryItem from './CountryItem';
import style from './CountryList.module.css'

export default function CountryList({countries}) {
    return (
    <div className={style.container}>
        {countries.map((country)=>(
        <CountryItem key={country.code} {...country}/>
        ))}
    </div>
    )
}

// countries가 전달되지 않았거나 배열이 아닐 경우 map메소드에서 오류가 발생할 수 있으므로 defaultProps로 처리
CountryList.defaultProps = {
    countries: [],
}
