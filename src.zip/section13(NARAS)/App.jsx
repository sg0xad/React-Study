import {Routes, Route} from 'react-router-dom'
import Home from './pages/Home'
import Search from './pages/Search'
import Country from './pages/Country'
import NotFound from './pages/NotFound'
import Layout from './components/Layout'
import './App.css'

function App() {

    return (
        <Layout>
            <Routes>
                <Route path="/" element={<Home/>}/> 
                <Route path="/search" element={<Search/>}/> 
                <Route path="/country/:code" element={<Country/>}/> {/* URL Parameter를 설정 (주소창에 URL 변수 안쓰면 404 NotFound) */}
                <Route path="*" element={<NotFound/>}/>
            </Routes>
        </Layout>
    )
}

export default App