import { useEffect, useState } from 'react';

function Hello() {
    // useEffect의 함수 안에서 리턴하는 함수(고차함수)로 컴포넌트가 없어질 때의 동작을 만들 수 있다.
    useEffect(() => {
        console.log("마운트");
        return () => console.log("언마운트");
    }, [])

    // 위와 동일
    // useEffect(function(){
    //     console.log("마운트");
    //     return function() {
    //         return console.log("언마운트");
    //     }
    // })
    
    return <h1>Hello</h1>;
}

export default function _02_UseEffect() {
    const [showing, setShowing] = useState(false);
    const onClick = () => setShowing((prev) => !prev);
    return (
    <div>
        {showing ? <Hello/> : null}
        <button onClick={onClick}>{showing ? "Hide" : "Show"}</button>
    </div>
    )
}

 