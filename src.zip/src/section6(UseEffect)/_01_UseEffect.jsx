import { useEffect, useState, useRef } from 'react';

export default function _01_UseEffect() {

  const [count, setCount] = useState(0);
  const [keyword, setKeyword] = useState("");

  const onClick = () => {
    setCount((prev) => prev + 1)
    // console.log(`카운트: ${count}`) // setState는 비동기이기 때문에 이 count 출력은 바뀐 값을 바로 반영 못함 (반영하려면 useEffect 사용)
  }

  // < 라이프사이클 >
  // 1. 마운트 (탄생)
  // 2. 업데이트 (변화, 리렌더)
  // 3. 언마운트 (죽음)

  // 첫번째 활용법
  useEffect(() => {
      console.log("언제나 실행됩니다.")
  }) // 두번째 인수(의존성 배열)이 없으면 렌더링될 때마다 실행

  // 두번째 활용법
  const isMountRef = useRef(false); 
  useEffect(() => {
      if (!isMountRef.current) {
          isMountRef.current = true;
          return;
      }
      console.log("마운트를 제외하고 언제나 실행됩니다.")
  }) 

  // 세번째 활용법
  useEffect(() => {
    console.log("한번만 실행됩니다.");
  }, []); // 의존성 배열이 빈 배열이면 한번만 실행 (마운트 때만)

  // 네번째 활용법
  useEffect(() => {
    console.log("keyword state가 바뀔 때마다 실행됩니다.");
  }, [keyword]); // 참고: 의존성 배열에는 요소를 여러개를 넣을 수 있다.


  return (
    <div>
      <h1>{count}</h1>
      <button onClick={onClick}>클릭</button>
    </div>
  );
}
 