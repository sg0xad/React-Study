import React, { useEffect } from 'react';
import axios from 'axios';

function _4_Axios_POST() {

    // < 첫번째 방법 >
    useEffect(() => {
        const postData = () => {
        axios.post('https://example.com/api/data', {
            key: 'value', // 전송할 데이터
        })
        .then((response) => {
            console.log('서버 응답:', response.data);
        })
        .catch((error) => {
            console.error('에러 발생:', error);
        });
        };

        postData();
    }, []); // 빈 배열을 전달하여 컴포넌트가 마운트될 때만 실행

 
    // < 두번째 방법 >
    // useEffect(() => {
    //     const postData = async () => {
    //     try {
    //         const response = await axios.post('https://example.com/api/data', {
    //         key: 'value', // 전송할 데이터
    //         });
    //         console.log('서버 응답:', response.data);
    //     } catch (error) {
    //         console.error('에러 발생:', error);
    //     }
    //     };

    //     postData();
    // }, []); // 빈 배열을 전달하여 컴포넌트가 마운트될 때만 실행

  return (
    <div>
      <h1>Axios를 이용한 데이터 전송 예시</h1>
    </div>
  );
};

export default _4_Axios_POST;