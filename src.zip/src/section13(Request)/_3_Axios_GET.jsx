import {useState, useEffect} from 'react'
import axios from 'axios' // axios를 사용하려면 터미널에 npm i axios 입력
function _3_Axios_GET() {
  const [posts, setPosts] = useState([]);



  // axios.get, axios.post, axios.put, axios.delete 등으로 여러가지 메소드로 요청할 수 있으며,
  // 객체를 전달하게 되면 자동으로 JSON 변환해서 보내준다.

  // < 첫번째 방법 >
  useEffect(() => {
    axios({
      method: 'GET',
      url: 'https://jsonplaceholder.typicode.com/photos?_limit=10'
    }).then(response => setPosts(response.data))
  }, [])

  // < 두번째 방법 > 
  // useEffect(() => {
  //   axios.get('https://jsonplaceholder.typicode.com/photos?_limit=10')
  //         .then(response => setPosts(response.data))
  //         .catch(error => {
  //             console.error("데이터를 불러오는 중 에러 발생:", error.response.data);
  //         });
  // }, [])

  // < 세번째 방법 >
  // useEffect(() => {
  //  const apiClient = axios.create(
  //    {
  //      baseURL: "https://jsonplaceholder.typicode.com/photos?_limit=10"
  //    }
  //  )
  //  apiClient.get("/photos")
  //         .then(response => setPosts(response.data))
  //         .catch(error => {
  //             console.error("데이터를 불러오는 중 에러 발생:", error.response.data);
  //         });
  // }, [])

  // < 네번째 방법 >
  // useEffect(() => {
  //   async function fetchData() {
  //     try {
  //       const response = await axios.get('https://jsonplaceholder.typicode.com/photos?_limit=10');
  //       setPosts(response.data);
  //     } catch (error) {
  //       console.error("데이터를 불러오는 중 에러 발생: ", error.response.data);
  //     }
  //   }
  //   fetchData();
  // }, []);

// < error 객체에 포함되는 것들 > 
// 1. message
// 오류 메시지를 포함. 일반적으로 오류의 원인에 대한 설명이 담김.
// 2. response
// 서버로부터의 응답을 포함하는 객체. 다음과 같은 속성을 가짐:
// data: 서버가 반환한 데이터 (예: 오류 메시지 또는 상태 코드에 대한 설명).
// status: HTTP 상태 코드 (예: 404, 500 등).
// statusText: 상태 코드에 대한 설명 (예: "Not Found", "Internal Server Error").
// headers: 서버 응답의 헤더 정보.
// config: 요청에 대한 설정 정보를 포함하는 객체.
// request: 요청에 대한 정보.
// 3. config
// 요청을 보낼 때 사용된 설정 정보를 포함하는 객체. 이 정보에는 요청 URL, 방법, 데이터, 헤더 등이 포함
// 4. isAxiosError
// 이 속성은 해당 오류가 Axios에서 발생한 오류임을 나타내는 불리언 값
 
useEffect(() => {
  console.log(posts)
}, [posts])

  return (
    <ul>
      {posts.map(post => (
        <li key={post.id}>
          <div>
            {post.title}
          </div>
          <div>
            <img src={post.thumbnailUrl} />
          </div>
        </li>
      ))}
    </ul>
  )
}

export default _3_Axios_GET
