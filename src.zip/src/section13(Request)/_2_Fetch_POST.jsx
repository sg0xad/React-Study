import React, { useEffect } from 'react';

function _2_Fetch_POST() {

// < 첫번째 방법 >
  useEffect(() => {
    const postData = () => {
      fetch('https://example.com/api/data', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ key: 'value' }), // 전송할 데이터
      })
      .then((response) => {
        if (!response.ok) {
          throw new Error('네트워크 응답이 올바르지 않습니다.');
        }
        return response.json(); // JSON 형태로 응답 데이터 파싱
      })
      .then((data) => {
        console.log('서버 응답:', data);
      })
      .catch((error) => {
        console.error('에러 발생:', error);
      });
    };

    postData();
  }, []); // 빈 배열을 전달하여 컴포넌트가 마운트될 때만 실행

// < 두번째 방법 >
//   useEffect(() => {
//     const postData = async () => {
//       try {
//         const response = await fetch('https://example.com/api/data', {
//           method: 'POST',
//           headers: {
//             'Content-Type': 'application/json',
//           },
//           body: JSON.stringify({ key: 'value' }), // 전송할 데이터
//         });

//         if (!response.ok) {
//           throw new Error('네트워크 응답이 올바르지 않습니다.');
//         }

//         const data = await response.json();
//         console.log('서버 응답:', data);
//       } catch (error) {
//         console.error('에러 발생:', error);
//       }
//     };

//     postData();
//   }, []); // 빈 배열을 전달하여 컴포넌트가 마운트될 때만 실행


  return (
    <div>
      <h1>데이터 전송 예시</h1>
    </div>
  );
};

export default _2_Fetch_POST;