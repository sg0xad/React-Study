import {useState, useEffect} from 'react'

function _1_Fetch_GET() {
  const [posts, setPosts] = useState([]);

  // < 첫번째 방법 >
  useEffect(() => {
    // API에서 데이터를 가져오는 GET 요청을 수행
    fetch('https://jsonplaceholder.typicode.com/photos?_limit=10')
      .then(response => {
        // 네트워크 응답이 성공적이지 않은 경우 에러를 throw
        if (!response.ok) {
          throw new Error('Network response was not ok');
        }
        // JSON 형태의 응답을 파싱하여 다음 then 블록으로 전달
        return response.json();
      })
      .then(data => {
        // 성공적으로 파싱된 데이터를 상태로 설정하여 컴포넌트에 반영
        setPosts(data);
      })
      .catch(error => {
        // 오류가 발생한 경우 에러 메시지를 출력
        console.error('Error fetching data:', error);
      });
  }, []);

  // < 두번째 방법 >
  // useEffect(() => {
  //   const fetchData = async () => {
  //     try {
  //       // API에서 데이터를 가져오는 GET 요청을 수행하고 응답을 기다림
  //       const response = await fetch('https://jsonplaceholder.typicode.com/photos');
        
  //       // 응답을 JSON으로 파싱하고 데이터를 기다립니다.
  //       const data = await response.json();
        
  //       // 성공적으로 데이터를 가져왔을 경우, 상태를 업데이트하여 컴포넌트에 반영
  //       setPosts(data);
  //     } catch (error) {
  //       // 오류가 발생한 경우, 콘솔에 오류 메시지를 출력
  //       console.log(error);
  //     }
  //   };
  //   fetchData();
  // }, []);

// < error 객체에 포함되는 것들 > 
// 1. message
// 오류 메시지를 포함. 일반적으로 오류의 원인에 대한 설명이 담김.
// 2. response
// 서버로부터의 응답을 포함하는 객체. 다음과 같은 속성을 가짐:
// data: 서버가 반환한 데이터 (예: 오류 메시지 또는 상태 코드에 대한 설명).
// status: HTTP 상태 코드 (예: 404, 500 등).
// statusText: 상태 코드에 대한 설명 (예: "Not Found", "Internal Server Error").
// headers: 서버 응답의 헤더 정보.
// config: 요청에 대한 설정 정보를 포함하는 객체.
// request: 요청에 대한 정보.
// 3. config
// 요청을 보낼 때 사용된 설정 정보를 포함하는 객체. 이 정보에는 요청 URL, 방법, 데이터, 헤더 등이 포함
// 4. isAxiosError
// 이 속성은 해당 오류가 Axios에서 발생한 오류임을 나타내는 불리언 값

  useEffect(() => {
    console.log(posts)
  }, [posts])

  return (
    <ul>
      {posts.map(post => (
        <li key={post.id}>
          <div>
            {post.title}
          </div>
          <div>
            <img src={post.thumbnailUrl} />
          </div>
          </li>
      ))}
    </ul>
  )
}

export default _1_Fetch_GET
