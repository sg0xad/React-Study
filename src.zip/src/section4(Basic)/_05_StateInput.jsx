import {useState} from 'react';

export default function _05_StateInput() {
    const [name, setName] = useState('')
    const [gender, setGender] = useState('')
    const [bio, setBio] = useState('')

    console.log(name)

    const onChange = (e) => {
        setName(e.target.value)
    }

    const onChangeGender = (e) => {
        setGender(e.target.value)
    }

    const onChangeBio = (e) => {
        setBio(e.target.value)
    }

    return ( 
        <div>
            <div>
                <input value={name} onChange={onChange}/>
            </div>
            <div>
                <select value={gender} onChange={onChangeGender}>
                    <option>밝히지 않음</option>
                    <option value="male">남성</option>
                    <option value="female">여성</option>
                </select>
            </div>
            <div>
                <textarea value={bio} onChange={onChangeBio}/>
            </div>
        </div>
    )
}