const _01_CssWithPorps = () => {
  const number = 10
  const string = "hello"
  const bool = true;
  const obj = {
      a : 1
  }

  const func = () => {
      return "func"
  }

  return (
      <div> {/* jsx문법에서는 모든 태그들을 최상위태그(div) 하나로 묶어야한다. */} {/* <> 빈 태그로도 가능 */}
          <h1>HEADER</h1>
          <h2>{10}</h2>
          <h2>{func()}</h2>
          <h2>{string}</h2>
          <h2>{bool}</h2> {/* 렌더링 X*/}
          <h2>{obj.a}</h2> {/* obj만 넣으면 오류 */}
          <img /> {/* jsx문법에서는 반드시 태그를 닫아야한다.*/}

          {/* 조건부 렌더링 */}
          {number % 2 === 0 ? (
              <div>{number}는 짝수입니다</div> 
          ) : (
              <div>{number}는 홀수입니다</div>
          )}
      </div>
      
  )
}
export default _01_CssWithPorps