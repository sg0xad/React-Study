import "./css/Header.css"
import style from './css/_02_CSS.module.css'
export default function _02_CSS() {
    return (
        <div>
            {/* CSS 적용하기 첫번째 방법 */}
            <div style={{
            backgroundColor: "green",
            borderBottom: "1px solid blue"
            }}>
                <h1>CSS 적용 1</h1>
            </div>

            {/* CSS 적용하기 두번째 방법 */}
            <div className="header"> {/* class 키워드는 js의 class으로 이미 예약어가 되어있기 때문에 className*/}
                <h1>CSS 적용 2</h1>
            </div>

            {/* CSS 적용하기 세번째 방법 */}
            {/* 단, css 이름을 컴포넌트.module.css 으로 해야한다 */}
            <div className={style.header}> {/* 개발자 도구에서 class명을 보면 난수화 돼서 적용되므로 다른 css파일의 클래스와 겹치지 않는다 */}
                <h1>CSS 적용 3</h1>
            </div>
        </div>
    )
}