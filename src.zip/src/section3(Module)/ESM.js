// ES 모듈 시스템 (이하 ESM) 

// import { add, sub } from './ESM_math.js'; // 확장자 필수
// import mul from './ESM_math.js'
import mul, { add, sub } from './ESM_module.js'

console.log(add(1, 2)); // 3
console.log(sub(1, 2)) // -1
console.log(mul(10, 20)) // 200
