// Common JS 모듈 시스템 (이하 CJS)
// require는 node.js가 기본적으로 제공하는 내장함수

// const moduleData = require('./CJS_module'); // add함수와 sub함수가 들어있는 객체를 할당

// console.log(moduleData.add(1, 2)); // 3
// console.log(moduleData.sub(1, 2)); // -1

// 구조분해 할당으로도 가능 ==================================================
const { add, sub } = require('./CJS_module'); // add함수와 sub함수가 들어있는 객체를 할당

console.log(add(1, 2)); // 3
console.log(sub(1, 2)); // -1