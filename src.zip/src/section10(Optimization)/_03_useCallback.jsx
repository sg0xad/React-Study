import { useState, memo, useCallback } from 'react'

const FirstComponent = memo(() => { 
  console.log('FirstComponent 렌더링')
  return (
    <div>
      <p>FirstComponent</p>
    </div>
  );
});

const SecondComponent = memo(({onClick}) => { 
    console.log('SecondComponent 렌더링')
    return (
        <div>
            <p>SecondComponent</p>
            <button onClick={onClick}>증가 버튼 (SecondComponent)</button>
        </div>
    )
})

function _03_useCallback() {
  const [value, setValue] = useState(0)

  
  // useCallback는 "메모이즈된" 즉, 기억된 함수를 반환하므로 함수의 재 생성을 방지한다.
  const onClick = useCallback(() => {
    // setValue(value + 1) onClick 함수는 한번만 생성돼서 setValue의 인수 value는 항상 0을 가리키게 되므로 1까지만 증가 된다.
    setValue(prevValue => prevValue + 1)
  }, [])

  return (
    <div> {/* 일반적으로 부모 컴포넌트인 _03_useCallback 컴포넌트가 렌더링 될 때마다 자식컴포넌트 리렌더링 */}
      <p>카운터 값: {value}</p> 
      <FirstComponent /> {/* 리렌더링 X */}
      <SecondComponent onClick={onClick} /> {/* 리렌더링 X */}
      <button onClick={onClick}>증가 버튼 (ParentComponent)</button>
    </div>
  );
}

export default _03_useCallback;