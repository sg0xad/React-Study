import { useState, memo } from 'react'

// React.memo를 쓰면 props가 바뀌지 않는 이상 부모 컴포넌트가 바뀌어도 리렌더링 X
// 모듈로 컴포넌트를 분리할 때는 export default memo(FirstComponent) 이렇게도 가능
const FirstComponent = memo(() => { 
  console.log('FirstComponent 렌더링')
  return (
    <div>
      <p>FirstComponent</p>
    </div>
  );
});

// SecondConponent는 React.memo를 적용해도 리렌더링 된다. 이유는 우선 props에는 함수가 있는 함수는 참조자료형이고, 참조자료형은 값이 아닌 주소를 참조한다.
// 그런데 부모의 부모 컴포넌트인 _02_memo 컴포넌트 안에 함수가 있고, 그 함수는 _02_memo 컴포넌트가 렌더링 될 때마다 생성되는데, 그때마다 생성된 새로운 주소값을 참조하기에
// props가 변경됐다고 판단되어 SecondConponent에 React.memo를 적용해도 리렌더링이 발생하는 문제가 생긴다.
const SecondComponent = memo(({onClick}) => { 
    console.log('SecondComponent 렌더링')
    return (
        <div>
            <p>SecondComponent</p>
            <button onClick={onClick}>증가 버튼 (SecondComponent)</button>
        </div>
    )
})

function _02_memo() {
  const [value, setValue] = useState(0)

  const onClick = () => {
    setValue(value + 1)
  }

  return (
    <div> {/* 일반적으로 부모 컴포넌트인 ParentComponent 컴포넌트가 렌더링 될 때마다 자식 컴포넌트 리렌더링 */}
      <p>카운터 값: {value}</p> 
      <FirstComponent /> {/* 리렌더링 X */}
      <SecondComponent onClick={onClick} /> {/* 리렌더링 O */}
      <button onClick={onClick}>증가 버튼 (ParentComponent)</button>
    </div>
  );
}

export default _02_memo;