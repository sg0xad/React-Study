import { useReducer } from 'react'

/* useReducer는 useState와 달리 컴포넌트 바깥에서 상태변화를 처리할 수 있다는 장점이 있다. */

function reducer(state, action) { // 첫번재 인수 state는 현재 state값
    if (action.type === 'DECREASE') {
        return state - action.data
    } else if (action.type === 'INCREASE') {
        return state + action.data
    }
}

export default function _02_useReducerVer() {
    // count: state의 값, dispatch: 함수(상태변화를 발동시키는 트리거)
    // dispatch 를 호출하면, reducer를 호출하며 reducer가 상태변화를 직접 처리
    const [count, dispatch] = useReducer(reducer, 0); // 두번째 인수: 초기값

    return (
        <div>
            <h4>{count}</h4>
            <div>
                <button onClick={()=>{
                    dispatch({
                        // 액션 객체
                        type : "DECREASE",
                        data : 1
                    });
                }}>-</button>
                <button onClick={()=>{
                    dispatch({
                        type: "INCREASE",
                        data: 1
                    })
                }
                }>+</button>
            </div>
        </div>
    )
}