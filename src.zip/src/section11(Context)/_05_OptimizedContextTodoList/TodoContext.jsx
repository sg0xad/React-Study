import {createContext} from 'react'

export const TodoStateContext = createContext() // 인수로 context가 다른 컴포넌트들에게 공급할 데이터의 초기값을 넣을 수 있다

export const TodoDispatchContext = createContext();