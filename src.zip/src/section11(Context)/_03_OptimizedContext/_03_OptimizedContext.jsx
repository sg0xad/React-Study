import React, { createContext, useContext, useReducer } from 'react';

// state와 dispatch를 위한 두 개의 별도 context 생성
const StateContext = createContext();
const DispatchContext = createContext();

const reducer = (state, action) => {
    switch (action.type) {
        case 'ACTION_TYPE':
            return { ...state, data: action.data };
        default:
            return state;
    }
};

const DisplayComponent = () => {
    const state = useContext(StateContext); // state context 사용
    return <div>{state.data}</div>;
};

const ChildComponent = () => {
    const dispatch = useContext(DispatchContext); // dispatch context 사용
    const handleOnClick = () => dispatch({ type: 'ACTION_TYPE', data: 'Hello, Context' });

    return <button onClick={handleOnClick}>Change Value</button>;
};



const _02_OptimizedContext = () => {
    const [state, dispatch] = useReducer(reducer, { data: 'Initial Data' }); // state 설정

    return (
        <DispatchContext.Provider value={dispatch}>
            <StateContext.Provider value={state}>
                <DisplayComponent />
                <ChildComponent />
            </StateContext.Provider>
        </DispatchContext.Provider>
    );
};

export default _02_OptimizedContext;