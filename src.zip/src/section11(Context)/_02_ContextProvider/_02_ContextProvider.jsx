import { useContext } from 'react';
import { MyContext } from './MyContext';


const _02_ContextProvider = () => {
    const contextData = useContext(MyContext);
    return (
        <MyContext.Provider value={"바뀐 데이터"}> {/* Provider로 컴포넌트들을 감싸면 모든 자손 컴포넌트들이 데이터를 공급받을 수 있다. */}
            <div>{contextData}</div> {/* 데이터 출력 */}
            <Sub />
        </MyContext.Provider>
    );
};

const Sub = () => {
    const contextData = useContext(MyContext); // context 사용 (부모 컴포넌트의 Provider value 값을 전달받는다)
    return (
        <div>
            <div>{contextData}</div> {/* 바뀐 데이터 출력 */}
        </div>
    );
};

export default _02_ContextProvider;