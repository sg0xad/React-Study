import { createContext } from 'react';
export const MyContext = createContext('데이터'); // context 생성 (createContext()의 인수로 다른 컴포넌트들에게 공급할 데이터의 초기값을 넣을 수 있다)