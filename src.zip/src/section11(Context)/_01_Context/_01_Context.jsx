import { useContext} from 'react';
import { myContext } from './MyContext';

function _01_Context() {
    // 언제 어디서든 myContext에 있는 값을 꺼내다가 쓸 수 있다.
    const contextData = useContext(myContext)
    return(
        <div>
            {contextData}
        </div>
    )
}

export default _01_Context