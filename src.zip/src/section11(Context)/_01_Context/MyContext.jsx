import { createContext } from 'react'

export const myContext = createContext("데이터")