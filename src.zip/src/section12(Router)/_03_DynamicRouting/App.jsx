import {Routes, Route, Link, useNavigate, BrowserRouter} from 'react-router-dom'
import Home from './pages/Home'
import Search from './pages/Search'
import Country from './pages/Country'
import NotFound from './pages/NotFound'

function Navigation() {
    const nav = useNavigate(); // nav 변수에 useNavigate 훅이 반환하는 페이지를 이동시킬 수 있는 함수가 저장
    const onClick = () => {
        nav('/search');
    };

    return (
        <div>
            <Link to={'/'}>Home</Link>
            <Link to={'/search'}>Search</Link>
            <Link to={'/country'}>Country</Link>
            <button onClick={onClick}>서치 페이지로 이동</button>
        </div>
    );
}

function App() {
    return (
        <BrowserRouter>
            <Routes>
                <Route path="/" element={<Home />} /> 
                <Route path="/search" element={<Search />} /> 
                <Route path="/country/:code" element={<Country />} /> {/* URL Parameter를 설정 */}
                <Route path="*" element={<NotFound />} />
            </Routes>
            <Navigation />
        </BrowserRouter>
    );
}

export default App;