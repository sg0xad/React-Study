import { useParams } from 'react-router-dom'

export default function Country() {
    // localhost:5173/country/KOR일 경우 params에 {code: 'KOR"} 저장
    const params = useParams()
  
    return <div>Country : {params.code}</div>
}

