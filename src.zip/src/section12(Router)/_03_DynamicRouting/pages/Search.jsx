import { useSearchParams } from 'react-router-dom'

export default function Search() {
    // searchParams: 현재 어떤 Query String들이 들어있는지 정보를 보관한고 있는 객체를 반환
    // setSearchParams: 현재 Query String의 값을 변경할 수 있는 함수를 반환
    const [searchParams, setSearchParams] = useSearchParams()

    // URL이 localhost:5173/search?p=123 으로 되어있다면 Search 123 출력
    return <div>Search {searchParams.get("p")}</div>
}