import {BrowserRouter, Routes, Route} from 'react-router-dom'
import Home from './pages/Home'
import Search from './pages/Search'
import Country from './pages/Country'
import NotFound from './pages/NotFound'

function App() {
    return (
        <BrowserRouter>
            <Routes>
                <Route path="/" element={<Home/>}/> {/* http://localhost:5173/ */}
                <Route path="/search" element={<Search/>}/> {/* http://localhost:5173/Search */}
                <Route path="/country" element={<Country/>}/> {/* http://localhost:5173/Country */}
                <Route path="*" element={<NotFound/>}/> {/* 위의 Route들에 걸리지 않았으면 모두 다 이 Route에 해당되게 한다.*/}
            </Routes>
        </BrowserRouter>
    )
}

export default App