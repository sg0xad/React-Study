import {BrowserRouter, Routes, Route, Link, useNavigate} from 'react-router-dom'
import Home from './pages/Home'
import Search from './pages/Search'
import Country from './pages/Country'
import NotFound from './pages/NotFound'

function Navigating() {
    // useNavigate를 사용하는 컴포넌트는 <BrowserRouter> 내부에 위치하고 있어야한다.
    const nav = useNavigate(); // nav 변수에 useNavigate 훅이 반환하는 페이지를 이동시킬 수 있는 함수가 저장
    const onClick = () => {
        nav('/search');
    };
    
    return (
        <div>
            <Link to={'/'}>Home</Link>
            <Link to={'/search'}>Search</Link>
            <Link to={'/country'}>Country</Link>
            <button onClick={onClick}>서치 페이지로 이동</button>
        </div>
    );
}

function App() {
    return (
        <BrowserRouter>
            <Routes>
                <Route path="/" element={<Home />} /> {/* http://localhost:5173/ */}
                <Route path="/search" element={<Search />} /> {/* http://localhost:5173/Search */}
                <Route path="/country" element={<Country />} /> {/* http://localhost:5173/Country */}
                <Route path="*" element={<NotFound />} /> {/* 위의 Route들에 걸리지 않았으면 모두 다 이 Route에 해당되게 한다.*/}
            </Routes>
            <Navigating />
        </BrowserRouter>
    );
}

export default App;