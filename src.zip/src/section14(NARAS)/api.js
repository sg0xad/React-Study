import axios from 'axios'

export async function fetchCountries() { // Home 컴포넌트가 렌더링 돼도 함수가 재생성 되는 것을 방지하기 위해 외부에 선언
    try {
      // await를 붙이면 API 호출의 결과를 기다렸다가 response 변수에 저장
      const response = await axios.get('https://naras-api.vercel.app/all') // https://naras-api.vercel.app/all 으로 요청한 후, 모든 국가 데이터 반환 (비동기)
     return response.data;
     } catch (e) {
         // 에러 대응 코드
         return []
     }
 }

 export async function fetchSearchResults(q) {
    try {
    const response = await axios.get(`https://naras-api.vercel.app/search?q=${q}`)
    return response.data
    } catch(e) {
        return []
    }
 }

 export async function fetchCountry(code) {
    try {
        const response = await axios.get(`https://naras-api.vercel.app/code/${code}`)
        return response.data
    } catch(e) {
        return null
    }
 }