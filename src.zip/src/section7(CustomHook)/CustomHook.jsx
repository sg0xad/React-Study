import { useState } from 'react'
import useInput from './hooks/useInput'
import useUpdate from './hooks/useUpdate'

export default function CustomerHook() {
  const [count, setCount] = useState(0);
  const [text, onChangeText] = useInput() // 커스텀 훅

  const onClick = () => {
    setCount((prev) => prev + 1)
  }

  useUpdate(()=>{
    console.log('마운트를 제외하고 언제나 실행됩니다.')
  }) // 커스텀 훅

  return (
    <div>
      <input
        value={text}
        onChange={onChangeText}
        type="text"
        placeholder="Search here..."
      />
      <h1>{count}</h1>
      <button onClick={onClick}>클릭</button>
    </div>
  );
}
 