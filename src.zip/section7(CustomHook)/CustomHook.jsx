import { useState } from 'react'
import useInput from './hooks/useInput'
import useUpdate from './hooks/useUpdate'

export default function CustomerHook() {
  const [count, setCount] = useState(0);
  const [text, onChangeText] = useInput() // 커스텀 훅

  const onClick = () => {
    setCount((prev) => prev + 1)
    // console.log(`카운트: ${count}`) // setState는 비동기이기 때문에 이 count 출력은 바뀐 값을 바로 반영 못하므로 useEffect 사용
  }

  useUpdate(()=>{
    console.log('마운트를 제외하고 언제나 실행됩니다.')
  }) // 커스텀 훅

  return (
    <div>
      <input
        value={text}
        onChange={onChangeText}
        type="text"
        placeholder="Search here..."
      />
      <h1>{count}</h1>
      <button onClick={onClick}>클릭</button>
    </div>
  );
}
 