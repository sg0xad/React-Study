import { useState, useEffect } from 'react'
import { useSearchParams } from 'react-router-dom'
import { fetchSearchResults } from '../api'
import Searchbar from '../components/Searchbar'
import CountryList from '../components/CountryList'
import style from './Search.module.css'

export default function Search() {
    // searchParams: 현재 어떤 Query String들이 들어있는지 정보를 보관한고 있는 객체를 반환
    // setSearchParams: 현재 Query String의 값을 변경할 수 있는 함수를 반환
    const [searchParams, setSearchParams] = useSearchParams()
    const q = searchParams.get("q");

    const [countries, setCountries] = useState([]);

    const setInitData = async () => {
        const data = await fetchSearchResults(q)
        setCountries(data)
    }

    useEffect(() => {
        setInitData()
    }, [q])

    // URL이 localhost:5173/search?p=123 으로 되어있다면 Search 123 출력
    return (
    <div className={style.container}>
        <Searchbar q={q} />
        <div>
            <b>{q}</b> 검색 결과
        </div>
        <CountryList countries={countries}/>
    </div>
    )
}